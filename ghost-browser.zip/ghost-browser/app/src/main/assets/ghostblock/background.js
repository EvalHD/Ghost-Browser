// Bekannte Werbe-/Tracking-Domains (inkl. Unterdomains). Hauptseiten selbst werden nie blockiert.
const BLOCKED = new Set([
  "doubleclick.net","googlesyndication.com","googleadservices.com","googletagservices.com",
  "adservice.google.com","pagead2.googlesyndication.com","2mdn.net","google-analytics.com",
  "adnxs.com","adsrvr.org","advertising.com","adform.net","adition.com","criteo.com","criteo.net",
  "taboola.com","outbrain.com","revcontent.com","mgid.com","rubiconproject.com","pubmatic.com",
  "openx.net","casalemedia.com","indexww.com","smartadserver.com","sharethrough.com","teads.tv",
  "amazon-adsystem.com","media.net","bidswitch.net","contextweb.com","lijit.com","sovrn.com",
  "33across.com","yieldmo.com","moatads.com","adsafeprotected.com","doubleverify.com",
  "scorecardresearch.com","quantserve.com","quantcount.com","adtech.com","adcolony.com",
  "applovin.com","unityads.unity3d.com","mopub.com","inmobi.com","vungle.com","chartboost.com",
  "tapjoy.com","ironsrc.com","supersonicads.com","startapp.com","smaato.net","popads.net",
  "popcash.net","propellerads.com","exoclick.com","juicyads.com","trafficjunky.net","adsterra.com",
  "clickadu.com","hilltopads.net","adcash.com","zedo.com","yllix.com","onclickads.net",
  "ad-maven.com","admaven.com","monetag.com","ads.twitter.com","ads-twitter.com",
  "analytics.twitter.com","ads.linkedin.com","ads.pinterest.com","ads.yahoo.com",
  "analytics.yahoo.com","adsymptotic.com","bluekai.com","krxd.net","demdex.net","everesttech.net",
  "rlcdn.com","mathtag.com","turn.com","tapad.com","agkn.com","adroll.com","perfectaudience.com",
  "serving-sys.com","eyeota.net","exelator.com","ml314.com","bounceexchange.com","hotjar.com",
  "mouseflow.com","crazyegg.com","fullstory.com","segment.io","mixpanel.com","amplitude.com",
  "branch.io","appsflyer.com","adjust.com","kochava.com","singular.net","onesignal.com",
  "tracking.vungle.com","adserver.snapads.com","an.facebook.com","pixel.facebook.com",
  "ads.tiktok.com","analytics.tiktok.com","business-api.tiktok.com","taboolasyndication.com",
  "adblade.com","content.ad","zemanta.com","nativo.com","triplelift.com","gumgum.com",
  "connatix.com","spotxchange.com","springserve.com","freewheel.tv","tidaltv.com","imrworldwide.com",
  "outbrainimg.com","ads.reddit.com","adhigh.net","adspyglass.com","cpmstar.com","bidvertiser.com"
]);

function isBlocked(host) {
  let h = host;
  while (true) {
    if (BLOCKED.has(h)) return true;
    const i = h.indexOf(".");
    if (i < 0) return false;
    h = h.slice(i + 1);
  }
}

browser.webRequest.onBeforeRequest.addListener(
  (details) => {
    try {
      const host = new URL(details.url).hostname.toLowerCase();
      if (isBlocked(host)) return { cancel: true };
    } catch (e) {}
    return {};
  },
  {
    urls: ["http://*/*", "https://*/*"],
    types: ["sub_frame", "stylesheet", "script", "image", "imageset", "object",
            "xmlhttprequest", "ping", "beacon", "font", "media", "websocket", "other"]
  },
  ["blocking"]
);
