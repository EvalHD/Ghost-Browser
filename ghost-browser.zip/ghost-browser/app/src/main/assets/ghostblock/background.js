// Ghost Werbeblocker v2 - Domain-Liste + Muster-Regeln + Pop-up/Push-Schutz.
// Erste Seite (die Seite, die du besuchst) wird nie durch Muster blockiert, nur Dritt-Anbieter.

const BLOCKED = new Set([
  "doubleclick.net","googlesyndication.com","googleadservices.com","googletagservices.com","adservice.google.com",
  "pagead2.googlesyndication.com","2mdn.net","google-analytics.com","adnxs.com","adsrvr.org",
  "advertising.com","adform.net","adition.com","criteo.com","criteo.net",
  "taboola.com","outbrain.com","revcontent.com","mgid.com","rubiconproject.com",
  "pubmatic.com","openx.net","casalemedia.com","indexww.com","smartadserver.com",
  "sharethrough.com","teads.tv","amazon-adsystem.com","media.net","bidswitch.net",
  "contextweb.com","lijit.com","sovrn.com","33across.com","yieldmo.com",
  "moatads.com","adsafeprotected.com","doubleverify.com","scorecardresearch.com","quantserve.com",
  "quantcount.com","adtech.com","adcolony.com","applovin.com","unityads.unity3d.com",
  "mopub.com","inmobi.com","vungle.com","chartboost.com","tapjoy.com",
  "ironsrc.com","supersonicads.com","startapp.com","smaato.net","popads.net",
  "popcash.net","propellerads.com","exoclick.com","juicyads.com","trafficjunky.net",
  "adsterra.com","clickadu.com","hilltopads.net","adcash.com","zedo.com",
  "yllix.com","onclickads.net","ad-maven.com","admaven.com","monetag.com",
  "ads.twitter.com","ads-twitter.com","analytics.twitter.com","ads.linkedin.com","ads.pinterest.com",
  "ads.yahoo.com","analytics.yahoo.com","adsymptotic.com","bluekai.com","krxd.net",
  "demdex.net","everesttech.net","rlcdn.com","mathtag.com","turn.com",
  "tapad.com","agkn.com","adroll.com","perfectaudience.com","serving-sys.com",
  "eyeota.net","exelator.com","ml314.com","bounceexchange.com","hotjar.com",
  "mouseflow.com","crazyegg.com","fullstory.com","segment.io","mixpanel.com",
  "amplitude.com","branch.io","appsflyer.com","adjust.com","kochava.com",
  "singular.net","onesignal.com","tracking.vungle.com","adserver.snapads.com","an.facebook.com",
  "pixel.facebook.com","ads.tiktok.com","analytics.tiktok.com","business-api.tiktok.com","taboolasyndication.com",
  "adblade.com","content.ad","zemanta.com","nativo.com","triplelift.com",
  "gumgum.com","connatix.com","spotxchange.com","springserve.com","freewheel.tv",
  "tidaltv.com","imrworldwide.com","outbrainimg.com","ads.reddit.com","adhigh.net",
  "adspyglass.com","cpmstar.com","bidvertiser.com","hilltopads.com","propellerclick.com",
  "propu.sh","pushails.com","rtmark.net","adsco.re","a-ads.com",
  "ad-score.com","ero-advertising.com","trafficstars.com","tsyndicate.com","realsrv.com",
  "magsrv.com","exosrv.com","exdynsrv.com","xlviirdr.com","clickaine.com",
  "richpush.co","pushwhy.com","pushground.com","notix.io","push-sdk.com",
  "evadav.com","evadavdsp.pro","galaksion.com","adskeeper.com","adskeeper.co.uk",
  "lentainform.com","clickadilla.com","highperformanceformat.com","profitablegatecpm.com","effectivegatecpm.com",
  "highcpmrevenuegate.com","profitablecpmrate.com","cpmrevenuegate.com","topcreativeformat.com","profitableratecpm.com",
  "effectiveratecpm.com","deloplen.com","deloton.com","alwingulla.com","nap5k.com",
  "groleegni.net","thubanoa.com","vaugroar.com","gizokraijaw.net","fpyf8.com",
  "5gvci.com","shoukigaigoors.net","forooqso.tv","tzegilo.com","cdn4ads.com",
  "onclkds.com","clkrev.com","popmyads.com","popunderjs.com","adsupply.com",
  "adxpansion.com","trafficfactory.biz","plugrush.com","ad4m.at","bidgear.com",
  "ads.exoclick.com","an.yandex.ru","yandexadexchange.net","adsrvmedia.net","ezoic.net",
  "ezodn.com","ezoic.com","ezojs.com","adthrive.com","raptive.com",
  "cafemedia.com","carbonads.com","carbonads.net","buysellads.com","adzerk.net",
  "adzerk.com","kargo.com","sonobi.com","undertone.com","conversantmedia.com",
  "vindicosuite.com","yieldlab.net","yieldlove.com","improvedigital.com","admixer.net",
  "admanmedia.com","adpushup.com","adgebra.in","adgear.com","adnxs-simple.com",
  "adingo.jp","i-mobile.co.jp","microad.jp","fout.jp","nend.net",
  "adlantis.jp","mookie1.com","ib-ibi.com","tribalfusion.com","atdmt.com",
  "chartbeat.net","nr-data.net","static.ads-twitter.com","snap.licdn.com","px.ads.linkedin.com",
  "adservice.google.de","adservice.google.at","adservice.google.ch","partner.googleadservices.com","pagead2.googleadservices.com",
  "tpc.googlesyndication.com","fundingchoicesmessages.google.com","ads.google.com","adsense.google.com","googleads.g.doubleclick.net",
  "securepubads.g.doubleclick.net","stats.g.doubleclick.net","smartclip.net","sascdn.com","adscale.de",
  "ligatus.com","ligatus.de","plista.com","nuggad.net","emetriq.de",
  "webtrekk.net","wt-eu02.net","etracker.com","ioam.de","yieldscale.com",
  "adtelligent.com","adkernel.com","adocean.pl","gemius.pl","gemius.com",
  "hit.gemius.pl","adverticum.net","ads.pubmatic.com","ads.rubiconproject.com","bidr.io",
  "id5-sync.com","liveramp.com","ssp.dojo.com","inner-active.mobi","inneractive.com",
  "fyber.com","tremorhub.com","tremor.com","spotx.tv","teads.com",
  "cdn.taboola.com","widgets.outbrain.com"
]);

// Reine Pop-up/Push/Adult-Netzwerke: werden auch als Seitenaufruf (neuer Tab/Weiterleitung) blockiert.
const POP_NETS = new Set([
  "popads.net","popcash.net","propellerads.com","exoclick.com","juicyads.com",
  "trafficjunky.net","adsterra.com","clickadu.com","hilltopads.net","hilltopads.com",
  "adcash.com","zedo.com","yllix.com","onclickads.net","ad-maven.com",
  "admaven.com","monetag.com","propellerclick.com","propu.sh","pushails.com",
  "rtmark.net","adsco.re","a-ads.com","ad-score.com","ero-advertising.com",
  "trafficstars.com","tsyndicate.com","realsrv.com","magsrv.com","exosrv.com",
  "exdynsrv.com","xlviirdr.com","clickaine.com","richpush.co","pushwhy.com",
  "pushground.com","notix.io","push-sdk.com","evadav.com","evadavdsp.pro",
  "galaksion.com","adskeeper.com","adskeeper.co.uk","lentainform.com","clickadilla.com",
  "highperformanceformat.com","profitablegatecpm.com","effectivegatecpm.com","highcpmrevenuegate.com","profitablecpmrate.com",
  "cpmrevenuegate.com","topcreativeformat.com","profitableratecpm.com","effectiveratecpm.com","deloplen.com",
  "deloton.com","alwingulla.com","nap5k.com","groleegni.net","thubanoa.com",
  "vaugroar.com","gizokraijaw.net","fpyf8.com","5gvci.com","shoukigaigoors.net",
  "forooqso.tv","tzegilo.com","cdn4ads.com","onclkds.com","clkrev.com",
  "popmyads.com","popunderjs.com","adsupply.com","adxpansion.com","trafficfactory.biz",
  "plugrush.com","ad4m.at","bidgear.com","ads.exoclick.com","an.yandex.ru",
  "yandexadexchange.net"
]);

// Dritt-Anbieter-URLs mit diesen Mustern sind Werbung (auch bei zufaelligen Domains).
const URL_PATTERNS = [
  /\/(pagead|adserver|adserving|adframe|adbanner|ad_banner|popunder|popads|pop-under|clickunder)\b/i,
  /\/(tag|micro|fp)\.min\.js(\?|$)/i,
  /\/(act|pfe\/current|pfe)\/(files\/)?(tag|micro)\.min\.js/i,
  /\/ntfc\.(php|js)(\?|$)/i,
  /\/sw\.js\?.*(zone|z=)/i,
  /[?&](zoneid|zone_id|campaignid|adunit|ad_unit|placementid)=/i,
  /\/(ads?|adv|banners?|adserve|advert(s|ising)?)\/[^/?]*\.(js|html?|php|gif|png|jpe?g|webp|mp4)(\?|$)/i,
  /\/(show_?ads?|ads?_?(loader|manager|script|config|tag))\.(js|php)/i,
  /\bpopunder|clickunder|pushnotif|inpagepush|in-page-push/i
];

// Typische Werbe-Subdomains (nur bei Dritt-Anbietern)
const HOST_PATTERN = /^(ads?|adserver\d*|adservice|pagead\d*|adx|banners?|popads?|track(er|ing)?|pixel|syndication|adtech|rtb|bid|prebid)\d*\./i;

function baseDomain(host) {
  const p = host.split(".");
  if (p.length <= 2) return host;
  const last = p[p.length - 1], second = p[p.length - 2];
  if (last.length === 2 && second.length <= 3 && p.length >= 3) {
    return p[p.length - 3] + "." + second + "." + last;
  }
  return second + "." + last;
}

function inSet(set, host) {
  let h = host;
  while (true) {
    if (set.has(h)) return true;
    const i = h.indexOf(".");
    if (i < 0) return false;
    h = h.slice(i + 1);
  }
}

function hostOf(u) {
  try { return new URL(u).hostname.toLowerCase(); } catch (e) { return null; }
}

browser.webRequest.onBeforeRequest.addListener(
  (details) => {
    try {
      const host = hostOf(details.url);
      if (!host) return {};

      // Eigene Erweiterungs-Anfragen (Listen-Download) nie blockieren
      if ((details.documentUrl || "").startsWith("moz-extension:")) return {};
      // Seiten auf der Ausnahmeliste (lange auf das Schild druecken) bleiben unberuehrt
      if (details.type !== "main_frame" && FilterEngine.isWhitelistedRequest(details)) return {};

      // Seitenaufruf (Tab/Weiterleitung): nur reine Pop-Netzwerke blockieren
      if (details.type === "main_frame") {
        if (inSet(POP_NETS, host)) return { cancel: true };
        return {};
      }

      if (inSet(BLOCKED, host)) return { cancel: true };

      const docUrl = details.documentUrl || details.originUrl || "";
      const docHost = hostOf(docUrl);
      const thirdParty = !!docHost && baseDomain(docHost) !== baseDomain(host);
      if (thirdParty) {
        if (HOST_PATTERN.test(host)) return { cancel: true };
        const url = details.url;
        for (let i = 0; i < URL_PATTERNS.length; i++) {
          if (URL_PATTERNS[i].test(url)) return { cancel: true };
        }
      }

      // EasyList / EasyList Germany / EasyPrivacy (auch Werbung vom Seitenbetreiber selbst)
      if (FilterEngine.shouldBlock(details, host, docHost, thirdParty)) return { cancel: true };
    } catch (e) {}
    return {};
  },
  {
    urls: ["http://*/*", "https://*/*"],
    types: ["main_frame", "sub_frame", "stylesheet", "script", "image", "imageset", "object",
            "xmlhttprequest", "ping", "beacon", "font", "media", "websocket", "other"]
  },
  ["blocking"]
);

// ---------- Nachrichten vom Inhalts-Skript ----------
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!msg) return;
  let top = hostOf((sender.tab && sender.tab.url) || "") || msg.host;
  if (msg.type === "init") {
    if (FilterEngine.isWhitelistedHost(top)) return Promise.resolve({ wl: true, cosmetic: [] });
    return Promise.resolve({ wl: false, cosmetic: FilterEngine.cosmeticFor(msg.host) });
  }
  if (msg.type === "generic") {
    if (FilterEngine.isWhitelistedHost(top)) return Promise.resolve([]);
    return Promise.resolve(FilterEngine.genericFor(msg.ids, msg.classes, msg.host));
  }
});

// ---------- Verbindung zur App (Ausnahmeliste) ----------
let nativeFails = 0;
function connectApp() {
  try {
    const port = browser.runtime.connectNative("browser");
    port.onMessage.addListener((m) => {
      nativeFails = 0;
      if (m && m.type === "whitelist") FilterEngine.setWhitelist(m.hosts || []);
    });
    port.onDisconnect.addListener(() => {
      nativeFails++;
      setTimeout(connectApp, nativeFails < 10 ? 3000 : 60000);
    });
  } catch (e) {
    nativeFails++;
    setTimeout(connectApp, nativeFails < 10 ? 3000 : 60000);
  }
}
connectApp();
FilterEngine.init();
