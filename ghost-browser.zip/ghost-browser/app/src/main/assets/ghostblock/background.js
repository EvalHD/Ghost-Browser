// Bekannte Werbe-/Tracking-Domains (inkl. Unterdomains). Hauptseiten selbst werden nie blockiert.
const BLOCKED = new Set([
  "doubleclick.net","googlesyndication.com","googleadservices.com","googletagservices.com",
  "adservice.google.com","pagead2.googlesyndication.com","2mdn.net","google-analytics.com",
  "adnxs.com","adsrvr.org","advertising.com","adform.net","adition.com","criteo.com","criteo.net",
  "taboola.com","outbrain.com","revcontent.com","mgid.com","rubiconproject.com","pubmatic.com",
  "openx.net","casalemedia.com","indexww.com","smartadserver.com","sharethrough.com","teads.tv",
  "amazon-adsystem.com","media.net","bidswitch.net","contextweb.com","lijit.com","sovrn.com",
  "33across.com","yieldmo.com","moatads.com","adsafeprotected.com","doubleverify.com",
  "scorecardresearch.com","quantserve.com","quantcount.com","adtech.com","adcolony.com",
  "applovin.com","unityads.unity3d.com","mopub.com","inmobi.com","vungle.com","chartboost.com",
  "tapjoy.com","ironsrc.com","supersonicads.com","startapp.com","smaato.net","popads.net",
  "popcash.net","propellerads.com","exoclick.com","juicyads.com","trafficjunky.net","adsterra.com",
  "clickadu.com","hilltopads.net","adcash.com","zedo.com","yllix.com","onclickads.net",
  "ad-maven.com","admaven.com","monetag.com","ads.twitter.com","ads-twitter.com",
  "analytics.twitter.com","ads.linkedin.com","ads.pinterest.com","ads.yahoo.com",
  "analytics.yahoo.com","adsymptotic.com","bluekai.com","krxd.net","demdex.net","everesttech.net",
  "rlcdn.com","mathtag.com","turn.com","tapad.com","agkn.com","adroll.com","perfectaudience.com",
  "serving-sys.com","eyeota.net","exelator.com","ml314.com","bounceexchange.com","hotjar.com",
  "mouseflow.com","crazyegg.com","fullstory.com","segment.io","mixpanel.com","amplitude.com",
  "branch.io","appsflyer.com","adjust.com","kochava.com","singular.net","onesignal.com",
  "tracking.vungle.com","adserver.snapads.com","an.facebook.com","pixel.facebook.com",
  "ads.tiktok.com","analytics.tiktok.com","business-api.tiktok.com","taboolasyndication.com",
  "adblade.com","content.ad","zemanta.com","nativo.com","triplelift.com","gumgum.com",
  "connatix.com","spotxchange.com","springserve.com","freewheel.tv","tidaltv.com","imrworldwide.com",
  "outbrainimg.com","ads.reddit.com","adhigh.net","adspyglass.com","cpmstar.com","bidvertiser.com"
]);


// Zusätzliche Domains (Push-Ads, Popunder, Miner, weitere Netzwerke)
["adskeeper.com","adskeeper.co.uk","rtbhouse.com","bidr.io","adtelligent.com","vidoomy.com",
 "undertone.com","kargo.com","sonobi.com","conversantmedia.com","emxdgt.com","improvedigital.com",
 "admixer.net","a-ads.com","coinzilla.com","coinhive.com","coin-hive.com","crypto-loot.com",
 "jsecoin.com","tsyndicate.com","trafficstars.com","realsrv.com","adzerk.net","buysellads.com",
 "static.ads-twitter.com","id5-sync.com","liveramp.com","ad-delivery.net","richpush.co",
 "mc.yandex.ru","an.yandex.ru","yandexadexchange.net","ad.mail.ru","adriver.ru","clickaine.com",
 "ads.youtube.com","ebayadservices.com","adsco.re","pushwoosh.com","notix.io","pushnami.com",
 "gadsme.com","adnuntius.com","seedtag.com","onetag-sys.com","ogury.com","teads.com",
 "smartadserver.com","sascdn.com","adgrx.com","pubmine.com","ad.gt","stackadapt.com",
 "tremorhub.com","innovid.com","brightcove-ads.com","imasdk.googleapis.com","adsafeprotected.com"
].forEach(d => BLOCKED.add(d));

function isBlocked(host) {
  let h = host;
  while (true) {
    if (BLOCKED.has(h)) return true;
    const i = h.indexOf(".");
    if (i < 0) break;
    h = h.slice(i + 1);
  }
  return LIST.has(host);
}

// ---- Große Hostliste (offline mitgeliefert, wird alle 3 Tage aktualisiert) ----
let LIST = new Set();
const LIST_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts";
const UPDATE_MS = 3 * 24 * 3600 * 1000;

function parseHosts(text) {
  const s = new Set();
  for (const line of text.split("\n")) {
    if (!line || line[0] === "#") continue;
    const p = line.trim().split(/\s+/);
    // Format "0.0.0.0 domain" oder reine Domain pro Zeile
    const d = (p.length >= 2 ? p[1] : p[0]).toLowerCase();
    if (d && d.includes(".") && d !== "0.0.0.0" && !d.startsWith("localhost")
        && d !== "googletagmanager.com" && d !== "www.googletagmanager.com") s.add(d);
  }
  return s;
}

async function loadList() {
  try {
    const r = await fetch(browser.runtime.getURL("hosts.txt"));
    LIST = parseHosts(await r.text());
  } catch (e) {}
  try {
    const st = await browser.storage.local.get(["hosts", "hostsTime"]);
    if (st.hosts && st.hosts.length > 1000) LIST = parseHosts(st.hosts);
    if (!st.hostsTime || Date.now() - st.hostsTime > UPDATE_MS) updateList();
  } catch (e) {}
}

async function updateList() {
  try {
    const r = await fetch(LIST_URL, { cache: "no-store" });
    if (!r.ok) return;
    const t = await r.text();
    const s = parseHosts(t);
    if (s.size > 10000) {
      LIST = s;
      await browser.storage.local.set({ hosts: t, hostsTime: Date.now() });
    }
  } catch (e) {}
}
loadList();

// ---- URL-Muster (nur bei Drittanbieter-Anfragen, damit Seiten nicht kaputtgehen) ----
const AD_PATTERNS = [
  /\/pagead\//i, /\/adserver\//i, /\/adserve\//i, /\/adframe/i, /\/adview/i,
  /\/ad[sx]?[-_]?(banner|slot|unit|tag|call|request|manager)\b/i,
  /[?&](ad_?type|ad_?unit|adslot|adzone)=/i,
  /\/(doubleclick|adsbygoogle|show_ads|show_ads_impl|prebid|pubads|pubads_impl)[\w.-]*\.js/i,
  /\/banners?\/ads?\//i, /\/sponsored[-_]?(links|ads)\//i, /\/vast\.xml/i, /\/ima3?\.js/i
];
// Immer blockieren (auch First-Party): bekannte Werbe-Skripte
const AD_SCRIPTS_ANY = /\/(adsbygoogle|show_ads_impl|pubads_impl|prebid(\.min)?)\.js(\?|$)/i;

function baseOf(host) {
  const p = host.split(".");
  if (p.length <= 2) return host;
  const last = p[p.length - 1], sec = p[p.length - 2];
  if (last.length === 2 && sec.length <= 3) return p.slice(-3).join(".");
  return sec + "." + last;
}

browser.webRequest.onBeforeRequest.addListener(
  (details) => {
    try {
      const u = new URL(details.url);
      const host = u.hostname.toLowerCase();
      if (isBlocked(host)) return { cancel: true };

      if (AD_SCRIPTS_ANY.test(u.pathname + u.search)) return { cancel: true };

      const doc = details.documentUrl || details.originUrl || "";
      if (doc) {
        const dh = new URL(doc).hostname.toLowerCase();
        const thirdParty = baseOf(dh) !== baseOf(host);
        if (thirdParty) {
          const path = u.pathname + u.search;
          for (const re of AD_PATTERNS) if (re.test(path)) return { cancel: true };
        }
      }
    } catch (e) {}
    return {};
  },
  {
    urls: ["http://*/*", "https://*/*"],
    types: ["sub_frame", "stylesheet", "script", "image", "imageset", "object",
            "xmlhttprequest", "ping", "beacon", "font", "media", "websocket", "other"]
  },
  ["blocking"]
);
