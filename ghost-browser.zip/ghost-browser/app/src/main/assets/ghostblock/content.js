// Ghost Werbeblocker v2 - Inhalts-Skript (laeuft in jeder Seite und jedem Frame)
(function () {
  "use strict";

  const win = window;
  const page = win.wrappedJSObject;

  function baseDomain(host) {
    const p = (host || "").split(".");
    if (p.length <= 2) return host || "";
    const last = p[p.length - 1], second = p[p.length - 2];
    if (last.length === 2 && second.length <= 3 && p.length >= 3) {
      return p[p.length - 3] + "." + second + "." + last;
    }
    return second + "." + last;
  }
  const myBase = baseDomain(location.hostname);

  function isCrossSite(url) {
    try {
      const u = new URL(url, location.href);
      if (u.protocol !== "http:" && u.protocol !== "https:") return false;
      return baseDomain(u.hostname) !== myBase;
    } catch (e) {
      return false;
    }
  }

  // ---------- 0) Grundzustand, Ausnahmeliste, Ausblend-Regeln ----------
  let off = false; // true = Seite steht auf der Ausnahmeliste
  const BASE_CSS = `/* Generische Werbe-Container ausblenden */
ins.adsbygoogle, .adsbygoogle, [id^="google_ads"], [id^="div-gpt-ad"], [id^="gpt-ad"],
[data-ad-slot], [data-ad-client], [data-ad-unit], [data-adunit],
[id^="adsbox"], .adsbox, .ad-banner, .adbanner, .banner-ad, .banner_ad, .ad-slot, .ad_slot,
.ad-wrapper, .ad-wrap, .advert, .advertisement, .advertise, .advertising, [id*="advertisement" i],
[class*="adsense" i], [id*="adsense" i], [class^="ad-" i][class*="container" i],
iframe[src*="doubleclick.net"], iframe[src*="googlesyndication"], iframe[src*="adservice"],
iframe[id^="google_ads"], iframe[id^="aswift"], iframe[src*="/ads/" i], iframe[src*="adsterra"],
iframe[src*="exoclick"], iframe[src*="propeller"], iframe[src*="monetag"],
[id*="taboola" i], [class*="taboola" i], .OUTBRAIN, [id*="outbrain" i], [class*="outbrain" i],
[id*="mgid" i], [class*="mgid" i], [class*="revcontent" i], [id^="rc-widget"],
[class*="sponsored-content" i], [class*="native-ad" i], [class*="nativead" i],
[class*="in-page-push" i], [class*="inpage-push" i], [class*="inpagepush" i],
[class*="push-notification-ad" i], [class*="interstitial-ad" i], [id*="interstitial-ad" i],
a[href$="/ad.com"], a[href*="://ad.com"], a[href*="//ads."], a[href*="adsterra.com"],
a[href*="exoclick.com"], a[href*="propellerads.com"], a[href*="monetag.com"],
a[href*="doubleclick.net/"], a[href*="googleadservices.com/"],
amp-ad, amp-embed[type="taboola"], amp-embed[type="outbrain"], amp-sticky-ad {
  display: none !important;
  visibility: hidden !important;
  width: 0 !important;
  height: 0 !important;
  min-height: 0 !important;
  max-height: 0 !important;
  overflow: hidden !important;
  pointer-events: none !important;
}
`;
  function addStyle(text) {
    const st = document.createElement("style");
    st.textContent = text;
    const parent = document.head || document.documentElement;
    if (parent) parent.appendChild(st);
    else document.addEventListener("DOMContentLoaded", () => (document.head || document.documentElement).appendChild(st), { once: true });
    return st;
  }
  const baseStyle = addStyle(BASE_CSS);
  const extraStyles = [];
  function hideSelectors(list) {
    for (let i = 0; i < list.length; i += 400) {
      const chunk = list.slice(i, i + 400).join(",\n");
      extraStyles.push(addStyle(chunk + " { display: none !important; }"));
    }
  }
  const seenC = new Set(), seenI = new Set();
  let pendC = [], pendI = [], genTimer = null;
  function noteEl(el) {
    if (el.id && !seenI.has(el.id)) { seenI.add(el.id); pendI.push(el.id); }
    const cl = el.classList;
    if (cl) for (let i = 0; i < cl.length; i++) {
      if (!seenC.has(cl[i])) { seenC.add(cl[i]); pendC.push(cl[i]); }
    }
  }
  function noteTree(root) {
    if (!root || root.nodeType !== 1) return;
    noteEl(root);
    const all = root.querySelectorAll("[id],[class]");
    for (let i = 0; i < all.length && i < 3000; i++) noteEl(all[i]);
  }
  function flushGeneric() {
    genTimer = null;
    if (off || (!pendC.length && !pendI.length)) return;
    const ids = pendI.splice(0, 1500), classes = pendC.splice(0, 1500);
    browser.runtime.sendMessage({ type: "generic", ids: ids, classes: classes, host: location.hostname })
      .then((sel) => { if (!off && sel && sel.length) hideSelectors(sel); }, () => {});
    if (pendC.length || pendI.length) genTimer = setTimeout(flushGeneric, 300);
  }
  function scheduleGeneric() { if (!genTimer) genTimer = setTimeout(flushGeneric, 400); }
  function startGeneric() {
    const go = () => {
      noteTree(document.documentElement);
      scheduleGeneric();
      new MutationObserver((muts) => {
        if (off) return;
        for (const m of muts) for (const n of m.addedNodes) noteTree(n);
        if (pendC.length || pendI.length) scheduleGeneric();
      }).observe(document.documentElement, { childList: true, subtree: true });
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go, { once: true });
    else go();
  }
  try {
    browser.runtime.sendMessage({ type: "init", host: location.hostname }).then((r) => {
      if (!r) { startGeneric(); return; }
      if (r.wl) {
        off = true;
        baseStyle.remove();
        return;
      }
      if (r.cosmetic && r.cosmetic.length) hideSelectors(r.cosmetic);
      startGeneric();
    }, () => {});
  } catch (e) {}

  // ---------- 1) Pop-ups / Pop-unders ----------
  let lastClick = { t: 0, interactive: false };
  const INTERACTIVE = "a[href],button,input,select,textarea,summary,label,[role=button],[role=link],[role=menuitem]";

  win.addEventListener("click", (e) => {
    let inter = false;
    try {
      inter = !!(e.isTrusted && e.target && e.target.closest && e.target.closest(INTERACTIVE));
    } catch (err) {}
    lastClick = { t: Date.now(), interactive: inter };
  }, true);

  try {
    exportFunction(function (url) {
      if (off) {
        try { return page.__ghostRealOpen.apply(page, arguments); } catch (e) {}
      }
      const recent = Date.now() - lastClick.t < 1500;
      // Erlaubt: echter Klick auf Link/Knopf (z.B. Login-Fenster). Alles andere ist ein Pop-up.
      if (recent && lastClick.interactive) {
        try {
          return page.__ghostRealOpen.apply(page, arguments);
        } catch (e) {}
      }
      return null;
    }, page, { defineAs: "__ghostOpenWrap" });
    page.__ghostRealOpen = page.open;
    page.open = page.__ghostOpenWrap;
  } catch (e) {}

  // Kuenstliche Klicks auf Links (typischer Pop-under-Trick) verbieten
  win.addEventListener("click", (e) => {
    if (off || e.isTrusted) return;
    try {
      const a = e.target && e.target.closest && e.target.closest("a");
      if (a && (a.target === "_blank" || isCrossSite(a.href))) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    } catch (err) {}
  }, true);

  // Klick auf unsichtbare Fremd-Links, die die ganze Seite bedecken (Click-Hijacking)
  win.addEventListener("click", (e) => {
    if (off || !e.isTrusted) return;
    try {
      const a = e.target && e.target.closest && e.target.closest("a[href]");
      if (!a) return;
      if (!isCrossSite(a.href) || a.target !== "_blank") return;
      const r = a.getBoundingClientRect();
      const cs = getComputedStyle(a);
      const big = r.width >= innerWidth * 0.8 && r.height >= innerHeight * 0.8;
      const hidden = parseFloat(cs.opacity) < 0.05;
      if (big || hidden) {
        e.preventDefault();
        e.stopImmediatePropagation();
        a.remove();
      }
    } catch (err) {}
  }, true);

  // ---------- 2) Push-Benachrichtigungen ----------
  try {
    if (page.Notification) {
      exportFunction(function () { return page.Promise.resolve("denied"); },
        page.Notification, { defineAs: "requestPermission" });
    }
  } catch (e) {}
  try {
    if (page.PushManager && page.PushManager.prototype) {
      exportFunction(function () {
        return page.Promise.reject(new page.Error("denied"));
      }, page.PushManager.prototype, { defineAs: "subscribe" });
    }
  } catch (e) {}

  // ---------- 3) Werbe-Overlays entfernen ----------
  const AD_TEXT = /(^|\s)(close ad|ad closes|advertisement|werbung schlie|anzeige schlie|skip ad)(\s|$)/i;
  const SAFE = "input,textarea,select,form,video,audio,[type=password]";
  const SAFE_TEXT = /(cookie|consent|datenschutz|privacy|login|anmelden|sign in|passwort|password|captcha|age|alter)/i;

  function looksLikeAdOverlay(el) {
    let cs;
    try { cs = getComputedStyle(el); } catch (e) { return false; }
    if (cs.position !== "fixed" && cs.position !== "absolute" && cs.position !== "sticky") return false;
    if (cs.display === "none" || cs.visibility === "hidden") return false;
    const z = parseInt(cs.zIndex, 10);
    if (!(z >= 1000)) return false;
    const r = el.getBoundingClientRect();
    const covers = r.width >= innerWidth * 0.6 && r.height >= innerHeight * 0.5;
    const small = r.width * r.height < innerWidth * innerHeight * 0.5;
    if (!covers && !small) return false;

    // Nie echte Dialoge mit Formularen/Cookie-Hinweisen entfernen
    try {
      if (el.querySelector(SAFE)) return false;
    } catch (e) {}
    const txt = (el.innerText || "").slice(0, 400);
    if (SAFE_TEXT.test(txt)) return false;

    // Merkmal 1: Text wie "Close Ad", "Advertisement"
    if (AD_TEXT.test(txt)) return true;

    // Merkmal 2: Fremd-Iframe als Vollbild-Overlay
    if (covers) {
      const ifr = el.tagName === "IFRAME" ? el : el.querySelector("iframe");
      if (ifr && isCrossSite(ifr.src || "")) return true;
      // Merkmal 3: leerer/transparenter Klick-Fanger mit Fremd-Link
      const a = el.tagName === "A" ? el : el.querySelector("a[href]");
      if (a && isCrossSite(a.href) && (parseFloat(cs.opacity) < 0.1 || !txt.trim())) return true;
    }
    // Merkmal 4: kleines Fremd-Iframe, fixiert (In-Page-Push, Sticky-Banner)
    if (el.tagName === "IFRAME" && isCrossSite(el.src || "") && cs.position === "fixed") return true;
    return false;
  }

  function restoreScroll() {
    try {
      for (const el of [document.documentElement, document.body]) {
        if (!el) continue;
        if (getComputedStyle(el).overflow === "hidden") el.style.setProperty("overflow", "auto", "important");
      }
    } catch (e) {}
  }

  function removeIfAd(el) {
    if (off || !el || el.nodeType !== 1) return;
    if (el === document.documentElement || el === document.body) return;
    if (looksLikeAdOverlay(el)) {
      el.remove();
      restoreScroll();
      return;
    }
    // Wrapper pruefen (Overlay liegt oft eine Ebene tiefer)
    const kids = el.children;
    for (let i = 0; i < kids.length && i < 6; i++) {
      if (looksLikeAdOverlay(kids[i])) {
        el.remove();
        restoreScroll();
        return;
      }
    }
  }

  function scanBody() {
    if (!document.body) return;
    const kids = document.body.children;
    for (let i = kids.length - 1; i >= 0 && i >= kids.length - 40; i--) removeIfAd(kids[i]);
  }

  function start() {
    const obs = new MutationObserver((muts) => {
      for (const m of muts) {
        for (const n of m.addedNodes) {
          if (n.nodeType === 1) setTimeout(() => removeIfAd(n), 150);
        }
      }
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    // Zusaetzlich in den ersten Sekunden regelmaessig pruefen (verzoegerte Overlays)
    let n = 0;
    const iv = setInterval(() => {
      scanBody();
      if (++n > 40) clearInterval(iv);
    }, 750);
    scanBody();
  }

  if (document.documentElement) start();
  else document.addEventListener("DOMContentLoaded", start, { once: true });
})();
