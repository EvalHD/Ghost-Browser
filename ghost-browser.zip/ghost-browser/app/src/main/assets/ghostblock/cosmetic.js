// Versteckt typische Werbeflächen und räumt leere Platzhalter auf.
(function () {
  if (window.top !== window && location.protocol === "about:") return;
  const SELECTORS = [
    "ins.adsbygoogle", ".adsbygoogle", "[id^='google_ads_']", "[id^='div-gpt-ad']",
    "[id^='ad-slot']", "[id^='adslot']", "[id^='taboola-']", "[id^='outbrain']",
    "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication']",
    "iframe[src*='adservice']", "iframe[id^='google_ads_iframe']",
    "iframe[src*='amazon-adsystem']", "iframe[src*='adnxs.com']",
    ".ad-banner", ".ad-container", ".ad-wrapper", ".ad-slot", ".ad-unit", ".ad-box",
    ".advert", ".advertisement", ".adsbox", ".ad-placeholder", ".banner-ad", ".banner_ad",
    ".sponsored-ad", ".sponsored-post", ".google-ad", ".dfp-ad", ".gpt-ad",
    ".taboola", ".trc_related_container", ".OUTBRAIN", ".ob-widget",
    "[data-ad-slot]", "[data-ad-unit]", "[data-google-query-id]",
    "[aria-label='Advertisement']", "[aria-label='Anzeige']", "[data-testid='ad']",
    "a[href*='doubleclick.net/']", "a[href*='googleadservices.com/']"
  ];
  const css = SELECTORS.join(",") + "{display:none!important;visibility:hidden!important;" +
              "height:0!important;min-height:0!important;max-height:0!important;" +
              "margin:0!important;padding:0!important;overflow:hidden!important}";

  function inject() {
    if (document.getElementById("ghostblock-css")) return;
    const st = document.createElement("style");
    st.id = "ghostblock-css";
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  }
  inject();
  new MutationObserver(inject).observe(document.documentElement, { childList: true });

  // Container, die nur noch ein verstecktes Werbeelement enthalten, ebenfalls einklappen
  function collapse() {
    document.querySelectorAll(SELECTORS.join(",")).forEach(el => {
      const p = el.parentElement;
      if (p && p !== document.body && p.children.length === 1 &&
          p.textContent.trim().length === 0) {
        p.style.setProperty("display", "none", "important");
      }
    });
  }
  let t = null;
  const obs = new MutationObserver(() => { if (!t) t = setTimeout(() => { t = null; collapse(); }, 400); });
  document.addEventListener("DOMContentLoaded", () => {
    collapse();
    obs.observe(document.body, { childList: true, subtree: true });
  });
})();
