// Ghost Werbeblocker - Filterlisten-Engine (EasyList-Syntax, laedt Listen selbst nach)
// Unterstuetzt: ||domain^, |anker|, *, ^, $third-party, $domain=, Typ-Optionen, @@Ausnahmen,
// sowie Ausblend-Regeln (##.klasse, ###id, domain.de##selektor, #@# Ausnahmen).
var FilterEngine = (function () {
  "use strict";

  const LISTS = [
    "https://easylist.to/easylist/easylist.txt",
    "https://easylist.to/easylistgermany/easylistgermany.txt",
    "https://easylist.to/easylist/easyprivacy.txt"
  ];
  const UPDATE_MS = 3 * 24 * 3600 * 1000;
  const ALL_TYPES = 2047;
  const TYPE_BIT = { script: 1, image: 2, stylesheet: 4, object: 8, xmlhttprequest: 16,
    subdocument: 32, ping: 64, media: 128, font: 256, websocket: 512, other: 1024 };
  const REQ_BIT = { script: 1, image: 2, imageset: 2, stylesheet: 4, object: 8, xmlhttprequest: 16,
    sub_frame: 32, ping: 64, beacon: 64, media: 128, font: 256, websocket: 512, other: 1024 };
  const OPT_ALIAS = { "3p": "third-party", "1p": "first-party", "xhr": "xmlhttprequest",
    "frame": "subdocument", "css": "stylesheet" };
  const IGNORE_OPTS = new Set(["important", "match-case", "all-types"]);

  function newIndex() { return { byHost: new Map(), byToken: new Map(), rest: [] }; }

  let blockIdx = newIndex(), allowIdx = newIndex();
  let domSel = new Map(), domExc = new Map(), genExc = new Set();
  let genId = new Map(), genClass = new Map();
  let whitelist = new Set();
  let ready = false;

  function baseDomain(host) {
    const p = host.split(".");
    if (p.length <= 2) return host;
    const last = p[p.length - 1], second = p[p.length - 2];
    if (last.length === 2 && second.length <= 3 && p.length >= 3) return p[p.length - 3] + "." + second + "." + last;
    return second + "." + last;
  }
  function hostOf(u) { try { return new URL(u).hostname.toLowerCase(); } catch (e) { return null; } }
  function suffixMatch(host, list) {
    for (let i = 0; i < list.length; i++) {
      const d = list[i];
      if (host === d || host.endsWith("." + d)) return true;
    }
    return false;
  }
  function toRegex(p) {
    let hostA = false, startA = false, endA = false;
    if (p.startsWith("||")) { hostA = true; p = p.slice(2); }
    else if (p[0] === "|") { startA = true; p = p.slice(1); }
    if (p.endsWith("|")) { endA = true; p = p.slice(0, -1); }
    let r = p.replace(/[.+?${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\^/g, "(?:[^\\w\\d_.%-]|$)");
    if (hostA) r = "^[a-z][a-z0-9+.-]*:\\/\\/(?:[^\\/?#]*\\.)?" + r;
    else if (startA) r = "^" + r;
    if (endA) r += "$";
    return new RegExp(r, "i");
  }

  function addRule(idx, rule, pattern) {
    // Host-Regel: ||host^ oder ||host/pfad
    if (pattern.startsWith("||")) {
      const m = /^\|\|([a-z0-9][a-z0-9.-]*\.[a-z0-9-]+)(.*)$/i.exec(pattern);
      if (m && !/\*/.test(m[1])) {
        const host = m[1].toLowerCase(), rest = m[2];
        rule.src = pattern;
        rule.all = rest === "" || rest === "^";
        let arr = idx.byHost.get(host);
        if (!arr) { arr = []; idx.byHost.set(host, arr); }
        arr.push(rule);
        return;
      }
    }
    // Token-Index: laengstes sauber begrenztes Stueck
    rule.src = pattern;
    const low = pattern.toLowerCase();
    let best = "";
    const re = /[a-z0-9%]{4,}/g;
    let t;
    while ((t = re.exec(low))) {
      const s = t.index, e = s + t[0].length;
      const before = s === 0 ? "|" : low[s - 1];
      const after = e >= low.length ? "|" : low[e];
      if (before === "*" || after === "*") continue;
      if (s === 0 && low[0] !== "|") continue;
      if (e >= low.length && low[low.length - 1] !== "|") continue;
      if (t[0].length > best.length) best = t[0];
    }
    if (best) {
      let arr = idx.byToken.get(best);
      if (!arr) { arr = []; idx.byToken.set(best, arr); }
      arr.push(rule);
    } else {
      idx.rest.push(rule);
    }
  }

  function parseNetwork(line, isAllow) {
    let pattern = line, opts = "";
    const di = line.lastIndexOf("$");
    if (di >= 0 && !(line.startsWith("/") && line.endsWith("/"))) {
      const o = line.slice(di + 1);
      if (/^[a-z0-9~_=|.,\-*]+$/i.test(o)) { pattern = line.slice(0, di); opts = o; }
    }
    if (!pattern || pattern === "*") return;
    if (pattern.startsWith("/") && pattern.endsWith("/") && pattern.length > 2) return; // Regex-Regeln auslassen
    const rule = { re: null, src: "", all: false, types: ALL_TYPES, third: 0, inc: null, exc: null };
    if (opts) {
      let pos = 0, neg = 0, hasPos = false;
      for (let o of opts.split(",")) {
        let n = false;
        if (o[0] === "~") { n = true; o = o.slice(1); }
        let name = o, val = "";
        const ei = o.indexOf("=");
        if (ei >= 0) { name = o.slice(0, ei); val = o.slice(ei + 1); }
        name = OPT_ALIAS[name] || name;
        if (IGNORE_OPTS.has(name)) continue;
        if (name === "third-party") { rule.third = n ? 2 : 1; continue; }
        if (name === "first-party") { rule.third = n ? 1 : 2; continue; }
        if (name === "domain") {
          rule.inc = []; rule.exc = [];
          for (const d of val.split("|")) {
            if (!d) continue;
            if (d[0] === "~") rule.exc.push(d.slice(1).toLowerCase()); else rule.inc.push(d.toLowerCase());
          }
          if (!rule.inc.length) rule.inc = null;
          continue;
        }
        if (TYPE_BIT[name]) {
          if (n) neg |= TYPE_BIT[name]; else { pos |= TYPE_BIT[name]; hasPos = true; }
          continue;
        }
        return; // nicht unterstuetzte Option -> Regel auslassen
      }
      rule.types = hasPos ? pos : (ALL_TYPES & ~neg);
      if (!rule.types) return;
    }
    addRule(isAllow ? allowIdx : blockIdx, rule, pattern);
  }

  const PROCEDURAL = /:(has-text|-abp-|xpath|matches-css|contains|upward|remove|style|watch-attr|min-text-length|nth-ancestor|not\(:)|^\+js/i;

  function parseCosmetic(line) {
    let sep = "##", i = line.indexOf("##"), exc = false;
    const j = line.indexOf("#@#");
    if (j >= 0 && (i < 0 || j < i)) { i = j; sep = "#@#"; exc = true; }
    if (i < 0) return false;
    if (/#[?$%]#|#@[?$%]#/.test(line)) return true; // erkannt, aber nicht unterstuetzt
    const doms = line.slice(0, i), sel = line.slice(i + sep.length).trim();
    if (!sel || PROCEDURAL.test(sel)) return true;
    if (doms.indexOf("~") >= 0) return true;
    const list = doms ? doms.split(",").map(function (d) { return d.trim().toLowerCase(); }).filter(Boolean) : [];
    if (!list.length) {
      if (exc) { genExc.add(sel); return true; }
      let m;
      if ((m = /^\.([\w-]+)$/.exec(sel))) {
        let a = genClass.get(m[1]); if (!a) { a = []; genClass.set(m[1], a); } a.push(sel);
      } else if ((m = /^#([\w-]+)$/.exec(sel))) {
        let a = genId.get(m[1]); if (!a) { a = []; genId.set(m[1], a); } a.push(sel);
      }
      return true;
    }
    for (const d of list) {
      const map = exc ? domExc : domSel;
      let a = map.get(d); if (!a) { a = exc ? new Set() : []; map.set(d, a); }
      if (exc) a.add(sel); else a.push(sel);
    }
    return true;
  }

  function parseText(text) {
    const lines = text.split("\n");
    for (let k = 0; k < lines.length; k++) {
      let line = lines[k].trim();
      if (!line || line[0] === "!" || line[0] === "[") continue;
      if (line.indexOf("#") >= 0 && parseCosmetic(line)) continue;
      let allow = false;
      if (line.startsWith("@@")) { allow = true; line = line.slice(2); }
      try { parseNetwork(line, allow); } catch (e) {}
    }
  }

  function matchRule(r, url, urlLow, third, bit, docHost) {
    if (!(r.types & bit)) return false;
    if (r.third === 1 && !third) return false;
    if (r.third === 2 && third) return false;
    if (r.inc && !(docHost && suffixMatch(docHost, r.inc))) return false;
    if (r.exc && docHost && suffixMatch(docHost, r.exc)) return false;
    if (r.all) return true;
    if (!r.re) { try { r.re = toRegex(r.src); } catch (e) { r.re = /$^/; } }
    return r.re.test(url);
  }

  function matchIndex(idx, url, host, third, bit, docHost) {
    const low = url.toLowerCase();
    let h = host;
    while (true) {
      const arr = idx.byHost.get(h);
      if (arr) for (let i = 0; i < arr.length; i++) if (matchRule(arr[i], url, low, third, bit, docHost)) return true;
      const d = h.indexOf(".");
      if (d < 0) break;
      h = h.slice(d + 1);
    }
    const toks = low.match(/[a-z0-9%]{4,}/g);
    if (toks) {
      const seen = new Set();
      for (let t = 0; t < toks.length; t++) {
        const tk = toks[t];
        if (seen.has(tk)) continue;
        seen.add(tk);
        const arr = idx.byToken.get(tk);
        if (arr) for (let i = 0; i < arr.length; i++) if (matchRule(arr[i], url, low, third, bit, docHost)) return true;
      }
    }
    for (let i = 0; i < idx.rest.length; i++) if (matchRule(idx.rest[i], url, low, third, bit, docHost)) return true;
    return false;
  }

  function shouldBlock(details, host, docHost, third) {
    if (!ready) return false;
    const bit = REQ_BIT[details.type];
    if (!bit) return false; // Seitenaufrufe nie ueber Listen blockieren
    if (!matchIndex(blockIdx, details.url, host, third, bit, docHost)) return false;
    if (matchIndex(allowIdx, details.url, host, third, bit, docHost)) return false;
    return true;
  }

  // ---------- Ausnahmeliste pro Seite ----------
  function setWhitelist(hosts) {
    whitelist = new Set((hosts || []).map(function (h) { return String(h).toLowerCase(); }));
    try { browser.storage.local.set({ ghost_wl: Array.from(whitelist) }); } catch (e) {}
  }
  function isWhitelistedHost(host) {
    if (!host) return false;
    let h = host;
    while (true) {
      if (whitelist.has(h)) return true;
      const i = h.indexOf(".");
      if (i < 0) return false;
      h = h.slice(i + 1);
    }
  }
  function isWhitelistedRequest(details) {
    let top = null;
    const fa = details.frameAncestors;
    if (fa && fa.length) top = fa[fa.length - 1].url;
    else top = details.documentUrl || details.originUrl || null;
    return isWhitelistedHost(top ? hostOf(top) : null);
  }

  // ---------- Ausblend-Regeln fuer Content-Skript ----------
  function cosmeticFor(host) {
    if (!ready || !host) return [];
    const out = [], excl = new Set(genExc);
    let h = host;
    const chain = [];
    while (true) {
      chain.push(h);
      const i = h.indexOf(".");
      if (i < 0) break;
      h = h.slice(i + 1);
    }
    for (const d of chain) { const e = domExc.get(d); if (e) e.forEach(function (s) { excl.add(s); }); }
    for (const d of chain) {
      const a = domSel.get(d);
      if (a) for (let i = 0; i < a.length; i++) if (!excl.has(a[i])) out.push(a[i]);
    }
    return out;
  }
  function genericFor(ids, classes, host) {
    if (!ready) return [];
    const out = [];
    const excl = new Set(genExc);
    let h = host || "";
    while (h) {
      const e = domExc.get(h); if (e) e.forEach(function (s) { excl.add(s); });
      const i = h.indexOf("."); if (i < 0) break; h = h.slice(i + 1);
    }
    (ids || []).forEach(function (id) { const a = genId.get(id); if (a) a.forEach(function (s) { if (!excl.has(s)) out.push(s); }); });
    (classes || []).forEach(function (c) { const a = genClass.get(c); if (a) a.forEach(function (s) { if (!excl.has(s)) out.push(s); }); });
    return out.slice(0, 2000);
  }

  // ---------- Laden / Aktualisieren ----------
  async function rebuildFromStorage() {
    const st = await browser.storage.local.get("ghost_lists");
    const lists = st.ghost_lists;
    if (!lists) return false;
    blockIdx = newIndex(); allowIdx = newIndex();
    domSel = new Map(); domExc = new Map(); genExc = new Set(); genId = new Map(); genClass = new Map();
    for (const url of Object.keys(lists)) parseText(lists[url]);
    ready = true;
    return true;
  }

  async function download() {
    const lists = {};
    let okCount = 0;
    const old = (await browser.storage.local.get("ghost_lists")).ghost_lists || {};
    for (const url of LISTS) {
      try {
        const r = await fetch(url, { cache: "no-store" });
        if (!r.ok) throw new Error("HTTP " + r.status);
        const txt = await r.text();
        if (txt.length < 1000) throw new Error("zu kurz");
        lists[url] = txt; okCount++;
      } catch (e) {
        if (old[url]) lists[url] = old[url];
      }
    }
    if (okCount > 0) {
      await browser.storage.local.set({ ghost_lists: lists, ghost_lists_time: Date.now() });
      return true;
    }
    return false;
  }

  async function init() {
    try {
      const w = await browser.storage.local.get("ghost_wl");
      if (w.ghost_wl) whitelist = new Set(w.ghost_wl);
    } catch (e) {}
    try {
      const had = await rebuildFromStorage();
      const t = (await browser.storage.local.get("ghost_lists_time")).ghost_lists_time || 0;
      if (!had || Date.now() - t > UPDATE_MS) {
        if (await download()) await rebuildFromStorage();
      }
    } catch (e) {}
    // Erneut pruefen, falls kein Netz beim Start war
    setTimeout(function () { if (!ready) init(); }, 5 * 60 * 1000);
  }

  return {
    init: init, shouldBlock: shouldBlock, setWhitelist: setWhitelist,
    isWhitelistedHost: isWhitelistedHost, isWhitelistedRequest: isWhitelistedRequest,
    cosmeticFor: cosmeticFor, genericFor: genericFor,
    _parseText: parseText, _isReady: function () { return ready; }, _setReady: function () { ready = true; }
  };
})();
