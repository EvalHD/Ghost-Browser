// YouTube: Werbung automatisch überspringen und Werbe-Elemente verstecken.
(function () {
  const css = [
    "#masthead-ad", "ytd-ad-slot-renderer", "ytd-promoted-sparkles-web-renderer",
    "ytd-display-ad-renderer", "ytd-banner-promo-renderer", "ytd-in-feed-ad-layout-renderer",
    ".ytp-ad-overlay-container", ".ytp-ad-module", "#player-ads", "#panels ytd-ads-engagement-panel-content-renderer",
    "ytm-promoted-sparkles-web-renderer", "ytm-companion-ad-renderer",
    "ytm-promoted-video-renderer", ".ad-container", "ad-slot-renderer"
  ].join(",") + "{display:none!important}";
  const st = document.createElement("style");
  st.textContent = css;
  (document.head || document.documentElement).appendChild(st);

  const SKIP = ".ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button";
  setInterval(() => {
    const player = document.querySelector(".html5-video-player");
    const adShowing = player && (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"));
    if (adShowing) {
      const v = document.querySelector("video.html5-main-video, video");
      if (v && isFinite(v.duration) && v.duration > 0) {
        v.muted = true;
        v.playbackRate = 16;
        try { v.currentTime = v.duration; } catch (e) {}
      }
    }
    document.querySelectorAll(SKIP).forEach(b => b.click());
  }, 250);
})();
