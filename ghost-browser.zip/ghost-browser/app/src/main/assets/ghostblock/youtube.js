// Ghost Werbeblocker - YouTube-Werbung (Werbung kommt vom Seitenbetreiber selbst)
// Wichtig: Alles ist abgesichert. Geht ein Teil schief, laedt YouTube trotzdem normal.
(function () {
  "use strict";
  const page = window.wrappedJSObject;
  let off = false;

  try {
    browser.runtime.sendMessage({ type: "init", host: location.hostname })
      .then((r) => { if (r && r.wl) off = true; }, () => {});
  } catch (e) {}

  function unwrap(o) {
    try { return (o && o.wrappedJSObject) ? o.wrappedJSObject : o; } catch (e) { return o; }
  }

  // 1) Werbe-Daten aus den Video-Informationen entfernen
  const AD_KEYS = ["adPlacements", "playerAds", "adSlots", "adBreakHeartbeatParams"];
  function dropKeys(t) {
    if (!t || typeof t !== "object") return;
    for (const k of AD_KEYS) {
      try {
        if (k in t) { try { delete t[k]; } catch (e) { t[k] = undefined; } }
      } catch (e) {}
    }
  }
  function clean(o) {
    if (off) return;
    try {
      const t = unwrap(o);
      if (!t || typeof t !== "object") return;
      dropKeys(t);
      const pr = t.playerResponse;
      if (pr && typeof pr === "object") dropKeys(pr);
    } catch (e) {}
  }

  // Die Aufrufe laufen ohne "arguments"/"apply", damit nichts zwischen Seite und
  // Erweiterung blockiert wird (das haette die ganze Seite lahmlegen koennen).
  try {
    const origParse = page.JSON.parse;
    exportFunction(function (text, reviver) {
      const r = (reviver === undefined)
        ? origParse.call(page.JSON, text)
        : origParse.call(page.JSON, text, reviver);
      clean(r);
      return r;
    }, page.JSON, { defineAs: "parse" });
  } catch (e) {}

  try {
    const origJson = page.Response.prototype.json;
    exportFunction(function () {
      const p = origJson.call(this);
      try {
        return p.then(exportFunction(function (r) { clean(r); return r; }, page));
      } catch (e) {
        return p;
      }
    }, page.Response.prototype, { defineAs: "json" });
  } catch (e) {}

  // Erste Seitendaten (ytInitialPlayerResponse) abfangen
  try {
    let stored;
    Object.defineProperty(page, "ytInitialPlayerResponse", {
      configurable: true,
      enumerable: true,
      get: exportFunction(function () { return stored; }, page),
      set: exportFunction(function (v) { clean(v); stored = unwrap(v); }, page)
    });
  } catch (e) {}

  // 2) Notfall: laufende Werbung ueberspringen
  function skipAds() {
    if (off) return;
    try {
      const player = document.querySelector(".html5-video-player");
      const showing = player && player.classList.contains("ad-showing");
      const btn = document.querySelector(
        ".ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-container button, .ytp-skip-ad-button__text");
      if (btn) btn.click();
      if (showing) {
        const v = player.querySelector("video");
        if (v && isFinite(v.duration) && v.duration > 0) {
          v.muted = true;
          v.playbackRate = 16;
          v.currentTime = Math.max(0, v.duration - 0.1);
        }
      }
      const ov = document.querySelectorAll(".ytp-ad-overlay-container, .ytp-ad-overlay-slot");
      for (const o of ov) o.remove();
    } catch (e) {}
  }
  try { setInterval(skipAds, 400); } catch (e) {}

  // 3) Werbe-Bereiche ausblenden
  const css = [
    "ytd-ad-slot-renderer", "ytd-in-feed-ad-layout-renderer", "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-web-renderer", "ytd-promoted-video-renderer", "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer", "ytd-player-legacy-desktop-watch-ads-renderer",
    "ytd-companion-slot-renderer", "ytd-action-companion-ad-renderer", "ytd-merch-shelf-renderer",
    "#masthead-ad", "#player-ads", ".ytp-ad-module", ".ytp-ad-overlay-container",
    "ytm-promoted-sparkles-web-renderer", "ytm-companion-ad-renderer", "ytm-promoted-video-renderer",
    "ad-slot-renderer", "ytm-ad-slot-renderer", ".ytd-ad-slot-renderer",
    "#related ytd-ad-slot-renderer", "tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)"
  ].join(",\n") + " { display: none !important; }";
  function addCss() {
    try {
      const st = document.createElement("style");
      st.textContent = css;
      (document.head || document.documentElement).appendChild(st);
    } catch (e) {}
  }
  if (document.documentElement) addCss();
  else document.addEventListener("DOMContentLoaded", addCss, { once: true });
})();
