// Ghost Werbeblocker - YouTube-Werbung (Werbung kommt vom Seitenbetreiber selbst)
(function () {
  "use strict";
  const page = window.wrappedJSObject;
  let off = false;

  try {
    browser.runtime.sendMessage({ type: "init", host: location.hostname })
      .then((r) => { if (r && r.wl) off = true; }, () => {});
  } catch (e) {}

  // 1) Werbe-Daten aus den Video-Informationen entfernen
  const AD_KEYS = ["adPlacements", "playerAds", "adSlots", "adBreakHeartbeatParams"];
  function clean(o) {
    if (off || !o || typeof o !== "object") return;
    try {
      const target = o.playerResponse && typeof o.playerResponse === "object" ? o.playerResponse : o;
      for (const k of AD_KEYS) {
        if (k in target) { try { delete target[k]; } catch (e) { target[k] = undefined; } }
      }
      if (target !== o) {
        for (const k of AD_KEYS) { if (k in o) { try { delete o[k]; } catch (e) {} } }
      }
    } catch (e) {}
  }

  try {
    const origParse = page.JSON.parse;
    exportFunction(function () {
      const r = origParse.apply(this, arguments);
      clean(r);
      return r;
    }, page.JSON, { defineAs: "parse" });
  } catch (e) {}

  try {
    const origJson = page.Response.prototype.json;
    exportFunction(function () {
      const p = origJson.apply(this, arguments);
      return p.then(exportFunction(function (r) { clean(r); return r; }, page));
    }, page.Response.prototype, { defineAs: "json" });
  } catch (e) {}

  // Erste Seitendaten (ytInitialPlayerResponse) abfangen
  try {
    let stored;
    Object.defineProperty(page, "ytInitialPlayerResponse", {
      configurable: true,
      get: exportFunction(function () { return stored; }, page),
      set: exportFunction(function (v) { clean(v); stored = v; }, page)
    });
  } catch (e) {}

  // 2) Notfall: laufende Werbung ueberspringen
  function skipAds() {
    if (off) return;
    try {
      const player = document.querySelector(".html5-video-player");
      const showing = player && player.classList.contains("ad-showing");
      const btn = document.querySelector(
        ".ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-container button");
      if (btn) btn.click();
      if (showing) {
        const v = player.querySelector("video");
        if (v && isFinite(v.duration) && v.duration > 0) {
          v.muted = true;
          v.playbackRate = 16;
          v.currentTime = Math.max(0, v.duration - 0.1);
        }
      }
      const ov = document.querySelectorAll(".ytp-ad-overlay-container, .ytp-ad-overlay-slot");
      for (const o of ov) o.remove();
    } catch (e) {}
  }
  setInterval(skipAds, 400);

  // 3) Werbe-Bereiche ausblenden
  const css = [
    "ytd-ad-slot-renderer", "ytd-in-feed-ad-layout-renderer", "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-web-renderer", "ytd-promoted-video-renderer", "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer", "ytd-player-legacy-desktop-watch-ads-renderer",
    "ytd-companion-slot-renderer", "ytd-action-companion-ad-renderer", "ytd-merch-shelf-renderer",
    "#masthead-ad", "#player-ads", ".ytp-ad-module", ".ytp-ad-overlay-container",
    "ytm-promoted-sparkles-web-renderer", "ytm-companion-ad-renderer", "ytm-promoted-video-renderer",
    "ad-slot-renderer", "ytm-ad-slot-renderer", ".ytd-ad-slot-renderer",
    "#related ytd-ad-slot-renderer", "tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)"
  ].join(",\n") + " { display: none !important; }";
  function addCss() {
    const st = document.createElement("style");
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);
  }
  if (document.documentElement) addCss();
  else document.addEventListener("DOMContentLoaded", addCss, { once: true });
})();
