package com.example.ghostbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.StorageController;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String START_URL = "resource://android/assets/start.html";
    // Suchmaschine fuer die Adressleiste (hier austauschbar)
    private static final String SEARCH_URL = "https://search.brave.com/search?q=";

    private static GeckoRuntime sRuntime;
    private GeckoSession session;
    private EditText urlBar;
    private View banner;
    private TextView bannerText;
    private ProgressBar progress;
    private ImageButton btnBack, btnForward;
    private boolean canGoBack = false;

    // Host der zuletzt erlaubten Seite
    private String baseHost = "";
    // Seiten, die du selbst angesteuert hast (Weiterleitungen dorthin, z.B. nach dem Login, sind ok)
    private final Set<String> trusted = new HashSet<>();
    // Ziel, das im Balken angezeigt wird
    private String pendingUri = null;

    private static final String CONFIG =
            "prefs:\n"
          + "  privacy.resistFingerprinting: true\n"
          + "  privacy.fingerprintingProtection: true\n"
          + "  privacy.firstparty.isolate: true\n"
          + "  network.http.referer.XOriginPolicy: 2\n"
          + "  network.http.referer.trimmingPolicy: 2\n"
          + "  media.peerconnection.ice.no_host: true\n"
          + "  media.peerconnection.ice.default_address_only: true\n"
          + "  geo.enabled: false\n"
          + "  dom.battery.enabled: false\n"
          + "  dom.netinfo.enabled: false\n"
          + "  dom.gamepad.enabled: false\n"
          + "  beacon.enabled: false\n"
          + "  browser.send_pings: false\n"
          + "  network.dns.disablePrefetch: true\n"
          + "  network.prefetch-next: false\n"
          + "  network.predictor.enabled: false\n"
          + "  privacy.donottrackheader.enabled: true\n"
          + "  network.trr.mode: 0\n";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GeckoView view = findViewById(R.id.geckoview);
        urlBar = findViewById(R.id.url);
        banner = findViewById(R.id.banner);
        bannerText = findViewById(R.id.banner_text);
        progress = findViewById(R.id.progress);
        btnBack = findViewById(R.id.btn_back);
        btnForward = findViewById(R.id.btn_forward);
        ImageButton btnHome = findViewById(R.id.btn_home);
        ImageButton btnReload = findViewById(R.id.btn_reload);
        Button go = findViewById(R.id.banner_go);
        Button close = findViewById(R.id.banner_close);

        if (sRuntime == null) {
            String cfgPath = writeConfig();
            GeckoRuntimeSettings.Builder rb = new GeckoRuntimeSettings.Builder()
                    .contentBlocking(new ContentBlocking.Settings.Builder()
                            .antiTracking(ContentBlocking.AntiTracking.STRICT)
                            .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
                            .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS)
                            .build())
                    .remoteDebuggingEnabled(false);
            if (cfgPath != null) rb.configFilePath(cfgPath);
            sRuntime = GeckoRuntime.create(this, rb.build());
        }

        // Normaler (nicht privater) Modus: Logins und Cookies bleiben gespeichert
        session = new GeckoSession();

        session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override
            public void onCanGoBack(GeckoSession s, boolean can) {
                canGoBack = can;
                btnBack.setAlpha(can ? 1f : 0.35f);
            }

            @Override
            public void onCanGoForward(GeckoSession s, boolean can) {
                btnForward.setAlpha(can ? 1f : 0.35f);
            }

            // Weiterleitungen auf FREMDE Seiten werden blockiert
            @Override
            public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, LoadRequest request) {
                String uri = request.uri;
                String host = hostOf(uri);
                if (host == null) {
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW); // about:, resource: usw.
                }
                String domain = baseDomain(host);
                boolean userInitiated = request.hasUserGesture
                        || (request.isDirectNavigation && !request.isRedirect);
                boolean byUser = userInitiated && !request.isRedirect;
                boolean sameSite = domain.equals(baseDomain(baseHost));

                if (sameSite || trusted.contains(domain) || byUser) {
                    baseHost = host;
                    if (byUser) trusted.add(domain);
                    hideBanner();
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                }
                showBanner(uri);
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }

            // Pop-ups / neue Fenster: nicht oeffnen, nur im Balken anbieten
            @Override
            public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
                showBanner(uri);
                return null;
            }
        });

        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override
            public void onPageStart(GeckoSession s, String url) {
                if (!urlBar.hasFocus()) {
                    urlBar.setText(url.startsWith("resource://") ? "" : url);
                }
                progress.setProgress(5);
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onProgressChange(GeckoSession s, int p) {
                progress.setProgress(p);
            }

            @Override
            public void onPageStop(GeckoSession s, boolean success) {
                progress.setVisibility(View.INVISIBLE);
            }
        });

        session.open(sRuntime);
        view.setSession(session);

        btnBack.setAlpha(0.35f);
        btnForward.setAlpha(0.35f);
        btnBack.setOnClickListener(v -> { if (canGoBack) session.goBack(); });
        btnForward.setOnClickListener(v -> session.goForward());
        btnHome.setOnClickListener(v -> session.loadUri(START_URL));
        btnReload.setOnClickListener(v -> session.reload());

        // Knopf oben: alle Cookies loeschen (mit Rueckfrage)
        ImageButton btnClear = findViewById(R.id.btn_clear);
        btnClear.setOnClickListener(v -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("Alle Cookies loeschen?")
                .setMessage("Du wirst danach auf allen Webseiten abgemeldet.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Loeschen", (d, w) ->
                        sRuntime.getStorageController()
                                .clearData(StorageController.ClearFlags.COOKIES)
                                .then(value -> {
                                    runOnUiThread(() -> {
                                        Toast.makeText(MainActivity.this,
                                                "Cookies geloescht", Toast.LENGTH_SHORT).show();
                                        session.reload();
                                    });
                                    return null;
                                }))
                .show());

        // "Weiter": erst jetzt geht es auf die fremde Seite
        go.setOnClickListener(v -> {
            String target = pendingUri;
            hideBanner();
            if (target != null) {
                String h = hostOf(target);
                if (h != null) {
                    baseHost = h;
                    trusted.add(baseDomain(h));
                }
                session.loadUri(target);
            }
        });
        close.setOnClickListener(v -> hideBanner());

        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
            if (enter) {
                session.loadUri(toUrl(urlBar.getText().toString()));
                urlBar.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                view.requestFocus();
                return true;
            }
            return false;
        });

        session.loadUri(START_URL);
    }

    private void showBanner(String uri) {
        runOnUiThread(() -> {
            pendingUri = uri;
            bannerText.setText("Weiterleitung blockiert:\n" + uri);
            banner.setVisibility(View.VISIBLE);
        });
    }

    private void hideBanner() {
        runOnUiThread(() -> {
            pendingUri = null;
            banner.setVisibility(View.GONE);
        });
    }

    private static String hostOf(String uri) {
        try {
            Uri u = Uri.parse(uri);
            String scheme = u.getScheme();
            if (scheme == null) return null;
            if (!scheme.equals("http") && !scheme.equals("https")) return null;
            String h = u.getHost();
            return h == null ? null : h.toLowerCase();
        } catch (Exception e) {
            return null;
        }
    }

    // grobe Hauptdomain: "www.google.com" -> "google.com", "a.bbc.co.uk" -> "bbc.co.uk"
    private static String baseDomain(String host) {
        if (host == null || host.isEmpty()) return "";
        String[] p = host.split("\\.");
        if (p.length <= 2) return host;
        String last = p[p.length - 1];
        String second = p[p.length - 2];
        if (last.length() == 2 && second.length() <= 3 && p.length >= 3) {
            return p[p.length - 3] + "." + second + "." + last;
        }
        return second + "." + last;
    }

    private String writeConfig() {
        try {
            File f = new File(getFilesDir(), "geckoview-config.yaml");
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(CONFIG.getBytes("UTF-8"));
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    private String toUrl(String input) {
        String t = input.trim();
        if (t.isEmpty()) return START_URL;
        if (t.contains(" ") || !t.contains(".")) {
            return SEARCH_URL + Uri.encode(t);
        }
        if (!t.contains("://")) return "https://" + t;
        return t;
    }

    @Override
    public void onBackPressed() {
        if (canGoBack) session.goBack();
        else super.onBackPressed();
    }
}
