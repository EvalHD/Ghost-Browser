package com.example.ghostbrowser;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private static GeckoRuntime sRuntime;
    private GeckoSession session;
    private EditText urlBar;
    private View banner;
    private TextView bannerText;
    private boolean canGoBack = false;

    // Host der zuletzt erlaubten Seite: damit erkennen wir Weiterleitungen auf FREMDE Seiten
    private String baseHost = "";
    // Ziel, das im Balken oben angezeigt wird
    private String pendingUri = null;

    // Privacy-Einstellungen der Firefox-Engine (about:config-Werte)
    private static final String CONFIG =
            "prefs:\n"
          + "  privacy.resistFingerprinting: true\n"
          + "  privacy.fingerprintingProtection: true\n"
          + "  privacy.firstparty.isolate: true\n"
          + "  network.http.referer.XOriginPolicy: 2\n"
          + "  network.http.referer.trimmingPolicy: 2\n"
          + "  media.peerconnection.ice.no_host: true\n"
          + "  media.peerconnection.ice.default_address_only: true\n"
          + "  geo.enabled: false\n"
          + "  dom.battery.enabled: false\n"
          + "  dom.netinfo.enabled: false\n"
          + "  dom.gamepad.enabled: false\n"
          + "  beacon.enabled: false\n"
          + "  browser.send_pings: false\n"
          + "  network.dns.disablePrefetch: true\n"
          + "  network.prefetch-next: false\n"
          + "  network.predictor.enabled: false\n"
          + "  privacy.donottrackheader.enabled: true\n"
          + "  network.trr.mode: 0\n";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GeckoView view = findViewById(R.id.geckoview);
        urlBar = findViewById(R.id.url);
        banner = findViewById(R.id.banner);
        bannerText = findViewById(R.id.banner_text);
        Button go = findViewById(R.id.banner_go);
        Button close = findViewById(R.id.banner_close);

        if (sRuntime == null) {
            String cfgPath = writeConfig();
            GeckoRuntimeSettings.Builder rb = new GeckoRuntimeSettings.Builder()
                    .contentBlocking(new ContentBlocking.Settings.Builder()
                            .antiTracking(ContentBlocking.AntiTracking.STRICT)
                            .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
                            .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS)
                            .build())
                    .remoteDebuggingEnabled(false);
            if (cfgPath != null) rb.configFilePath(cfgPath);
            sRuntime = GeckoRuntime.create(this, rb.build());
        }

        // Privater Modus: Verlauf und Cookies werden nicht gespeichert
        session = new GeckoSession(new GeckoSessionSettings.Builder()
                .usePrivateMode(true)
                .build());

        session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override
            public void onCanGoBack(GeckoSession s, boolean can) {
                canGoBack = can;
            }

            // Jede Navigation pruefen: Weiterleitungen auf andere Webseiten werden blockiert
            @Override
            public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, LoadRequest request) {
                String uri = request.uri;
                String host = hostOf(uri);
                if (host == null) {
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW); // about:, resource: usw.
                }
                boolean userInitiated = request.hasUserGesture
                        || (request.isDirectNavigation && !request.isRedirect);
                boolean sameSite = baseDomain(host).equals(baseDomain(baseHost));

                if (sameSite || (userInitiated && !request.isRedirect)) {
                    baseHost = host;
                    hideBanner();
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                }
                showBanner(uri);
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }

            // Pop-ups / neue Fenster: nicht oeffnen, nur im Balken anbieten
            @Override
            public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
                showBanner(uri);
                return null;
            }
        });

        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override
            public void onPageStart(GeckoSession s, String url) {
                if (!urlBar.hasFocus()) urlBar.setText(url);
            }
        });

        session.open(sRuntime);
        view.setSession(session);

        // Knopf "Weiter": erst jetzt wird auf die fremde Seite gegangen
        go.setOnClickListener(v -> {
            String target = pendingUri;
            hideBanner();
            if (target != null) {
                baseHost = hostOf(target) == null ? "" : hostOf(target);
                session.loadUri(target);
            }
        });
        close.setOnClickListener(v -> hideBanner());

        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
            if (enter) {
                session.loadUri(toUrl(urlBar.getText().toString()));
                urlBar.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                view.requestFocus();
                return true;
            }
            return false;
        });

        session.loadUri("https://duckduckgo.com");
    }

    private void showBanner(String uri) {
        runOnUiThread(() -> {
            pendingUri = uri;
            bannerText.setText("Weiterleitung blockiert:\n" + uri);
            banner.setVisibility(View.VISIBLE);
        });
    }

    private void hideBanner() {
        runOnUiThread(() -> {
            pendingUri = null;
            banner.setVisibility(View.GONE);
        });
    }

    // Host einer http(s)-Adresse, sonst null
    private static String hostOf(String uri) {
        try {
            Uri u = Uri.parse(uri);
            String scheme = u.getScheme();
            if (scheme == null) return null;
            if (!scheme.equals("http") && !scheme.equals("https")) return null;
            String h = u.getHost();
            return h == null ? null : h.toLowerCase();
        } catch (Exception e) {
            return null;
        }
    }

    // grobe Hauptdomain: "www.google.com" -> "google.com", "a.bbc.co.uk" -> "bbc.co.uk"
    private static String baseDomain(String host) {
        if (host == null || host.isEmpty()) return "";
        String[] p = host.split("\\.");
        if (p.length <= 2) return host;
        String last = p[p.length - 1];
        String second = p[p.length - 2];
        if (last.length() == 2 && second.length() <= 3 && p.length >= 3) {
            return p[p.length - 3] + "." + second + "." + last;
        }
        return second + "." + last;
    }

    private String writeConfig() {
        try {
            File f = new File(getFilesDir(), "geckoview-config.yaml");
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(CONFIG.getBytes("UTF-8"));
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    private String toUrl(String input) {
        String t = input.trim();
        if (t.isEmpty()) return "https://duckduckgo.com";
        if (t.contains(" ") || !t.contains(".")) {
            return "https://duckduckgo.com/?q=" + Uri.encode(t);
        }
        if (!t.contains("://")) return "https://" + t;
        return t;
    }

    @Override
    public void onBackPressed() {
        if (canGoBack) session.goBack();
        else super.onBackPressed();
    }
}
