package com.example.ghostbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.StorageController;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebExtensionController;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String START_URL = "resource://android/assets/start.html";
    private static final String[] SEARCH_URLS = {
            "https://www.google.com/search?q=",
            "https://search.brave.com/search?q=",
            "https://www.startpage.com/do/search?q=",
            "https://duckduckgo.com/?q=",
            "https://www.qwant.com/?q="
    };

    static GeckoRuntime sRuntime;
    private static WebExtension sAdExt;
    private static boolean sAdSetupStarted = false;

    // Ein Tab = eine eigene Browser-Sitzung
    private static class Tab {
        GeckoSession session;
        String url = "";
        String title = "";
        boolean canBack = false;
        boolean canForward = false;
    }

    private final List<Tab> tabs = new ArrayList<>();
    private int curIdx = 0;

    private SharedPreferences sp;
    private GeckoView geckoView;
    private EditText urlBar;
    private View banner;
    private TextView bannerText;
    private ProgressBar progress;
    private ImageButton btnBack, btnForward, btnAd;
    private TextView tabsBtn;
    private View tabPanel;
    private LinearLayout tabList;

    private Boolean lastAd = null;
    private Boolean lastDesktop = null;

    private String baseHost = "";
    private final Set<String> trusted = new HashSet<>();
    private String pendingUri = null;
    private boolean pendingNewTab = false;

    private Tab cur() {
        return tabs.get(curIdx);
    }

    private String buildConfig() {
        StringBuilder c = new StringBuilder("prefs:\n");
        if (sp.getBoolean("fingerprint", true)) {
            c.append("  privacy.resistFingerprinting: true\n");
            c.append("  privacy.fingerprintingProtection: true\n");
        }
        c.append("  privacy.firstparty.isolate: true\n");
        c.append("  network.http.referer.XOriginPolicy: 2\n");
        c.append("  network.http.referer.trimmingPolicy: 2\n");
        c.append("  media.peerconnection.ice.no_host: true\n");
        c.append("  media.peerconnection.ice.default_address_only: true\n");
        c.append("  geo.enabled: false\n");
        c.append("  dom.battery.enabled: false\n");
        c.append("  dom.netinfo.enabled: false\n");
        c.append("  dom.gamepad.enabled: false\n");
        c.append("  beacon.enabled: false\n");
        c.append("  browser.send_pings: false\n");
        c.append("  network.dns.disablePrefetch: true\n");
        c.append("  network.prefetch-next: false\n");
        c.append("  network.predictor.enabled: false\n");
        c.append("  privacy.donottrackheader.enabled: true\n");
        c.append("  network.trr.mode: 0\n");
        return c.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences(SettingsActivity.PREFS, MODE_PRIVATE);

        geckoView = findViewById(R.id.geckoview);
        urlBar = findViewById(R.id.url);
        banner = findViewById(R.id.banner);
        bannerText = findViewById(R.id.banner_text);
        progress = findViewById(R.id.progress);
        btnBack = findViewById(R.id.btn_back);
        btnForward = findViewById(R.id.btn_forward);
        btnAd = findViewById(R.id.btn_adblock);
        tabsBtn = findViewById(R.id.btn_tabs);
        tabPanel = findViewById(R.id.tab_panel);
        tabList = findViewById(R.id.tab_list);
        ImageButton btnHome = findViewById(R.id.btn_home);
        ImageButton btnReload = findViewById(R.id.btn_reload);
        ImageButton btnSettings = findViewById(R.id.btn_settings);
        Button go = findViewById(R.id.banner_go);
        Button close = findViewById(R.id.banner_close);

        if (sRuntime == null) {
            String cfgPath = writeConfig();
            GeckoRuntimeSettings.Builder rb = new GeckoRuntimeSettings.Builder()
                    .contentBlocking(new ContentBlocking.Settings.Builder()
                            .antiTracking(ContentBlocking.AntiTracking.STRICT)
                            .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
                            .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS)
                            .build())
                    .remoteDebuggingEnabled(false);
            if (cfgPath != null) rb.configFilePath(cfgPath);
            sRuntime = GeckoRuntime.create(this, rb.build());
        }
        setupAdExtension();

        // Untere Leiste
        btnBack.setOnClickListener(v -> { if (cur().canBack) cur().session.goBack(); });
        btnForward.setOnClickListener(v -> { if (cur().canForward) cur().session.goForward(); });
        btnHome.setOnClickListener(v -> cur().session.loadUri(START_URL));
        btnReload.setOnClickListener(v -> cur().session.reload());
        btnAd.setOnClickListener(v -> {
            boolean now = !sp.getBoolean("adblock", true);
            sp.edit().putBoolean("adblock", now).apply();
            applySettings();
            Toast.makeText(MainActivity.this,
                    now ? "Werbeblocker an" : "Werbeblocker aus", Toast.LENGTH_SHORT).show();
        });
        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SettingsActivity.class)));

        // Tabs
        tabsBtn.setOnClickListener(v -> openTabPanel());
        findViewById(R.id.tab_done).setOnClickListener(v -> closeTabPanel());
        findViewById(R.id.tab_new).setOnClickListener(v -> {
            closeTabPanel();
            openNewTab(START_URL);
        });

        // Cookie-Knopf oben
        ImageButton btnClear = findViewById(R.id.btn_clear);
        btnClear.setOnClickListener(v -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("Alle Cookies löschen?")
                .setMessage("Du wirst danach auf allen Webseiten abgemeldet.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Löschen", (d, w) ->
                        sRuntime.getStorageController()
                                .clearData(StorageController.ClearFlags.COOKIES)
                                .then(value -> {
                                    runOnUiThread(() -> {
                                        Toast.makeText(MainActivity.this,
                                                "Cookies gelöscht", Toast.LENGTH_SHORT).show();
                                        cur().session.reload();
                                    });
                                    return null;
                                }))
                .show());

        // Balken: "Weiter"
        go.setOnClickListener(v -> {
            String target = pendingUri;
            boolean inNewTab = pendingNewTab;
            hideBanner();
            if (target != null) {
                String h = hostOf(target);
                if (h != null) {
                    baseHost = h;
                    trusted.add(baseDomain(h));
                }
                if (inNewTab) openNewTab(target);
                else cur().session.loadUri(target);
            }
        });
        close.setOnClickListener(v -> hideBanner());

        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = actionId == EditorInfo.IME_ACTION_GO
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
            if (enter) {
                cur().session.loadUri(toUrl(urlBar.getText().toString()));
                urlBar.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                geckoView.requestFocus();
                return true;
            }
            return false;
        });

        // Erster Tab
        Tab first = createTab();
        switchTo(tabs.indexOf(first));
        first.session.loadUri(START_URL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        applySettings();
    }

    // ================= Tabs =================
    private Tab createTab() {
        final Tab tab = new Tab();
        final GeckoSession gs = new GeckoSession();
        tab.session = gs;

        gs.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override
            public void onCanGoBack(GeckoSession s, boolean can) {
                tab.canBack = can;
                if (isCurrent(tab)) updateNavButtons();
            }

            @Override
            public void onCanGoForward(GeckoSession s, boolean can) {
                tab.canForward = can;
                if (isCurrent(tab)) updateNavButtons();
            }

            @Override
            public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, LoadRequest request) {
                String uri = request.uri;
                String host = hostOf(uri);
                if (host == null) {
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW); // about:, resource: usw.
                }

                // Suchfeld der Startseite -> gewählte Suchmaschine
                if (host.equals("ghost.search")) {
                    String q = Uri.parse(uri).getQueryParameter("q");
                    if (q != null && !q.trim().isEmpty()) {
                        final String target = searchUrl() + Uri.encode(q.trim());
                        runOnUiThread(() -> gs.loadUri(target));
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY);
                }

                if (!sp.getBoolean("redirect_guard", true)) {
                    baseHost = host;
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                }

                String domain = baseDomain(host);
                boolean userInitiated = request.hasUserGesture
                        || (request.isDirectNavigation && !request.isRedirect);
                boolean byUser = userInitiated && !request.isRedirect;
                boolean sameSite = domain.equals(baseDomain(baseHost));

                if (sameSite || trusted.contains(domain) || byUser) {
                    baseHost = host;
                    if (byUser) trusted.add(domain);
                    hideBanner();
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW);
                }
                showBanner(uri, false);
                return GeckoResult.fromValue(AllowOrDeny.DENY);
            }

            // Neue Fenster: mit Schutz -> Balken, ohne Schutz -> neuer Tab
            @Override
            public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
                if (sp.getBoolean("redirect_guard", true)) {
                    showBanner(uri, true);
                } else {
                    runOnUiThread(() -> openNewTab(uri));
                }
                return null;
            }
        });

        gs.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override
            public void onPageStart(GeckoSession s, String url) {
                tab.url = url;
                if (isCurrent(tab)) {
                    if (!urlBar.hasFocus()) urlBar.setText(displayUrl(url));
                    progress.setProgress(5);
                    progress.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onProgressChange(GeckoSession s, int p) {
                if (isCurrent(tab)) progress.setProgress(p);
            }

            @Override
            public void onPageStop(GeckoSession s, boolean success) {
                if (isCurrent(tab)) progress.setVisibility(View.INVISIBLE);
            }
        });

        gs.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override
            public void onTitleChange(GeckoSession s, String title) {
                tab.title = title == null ? "" : title;
            }
        });

        applyDesktopMode(gs, sp.getBoolean("desktop", false));
        gs.open(sRuntime);
        tabs.add(tab);
        updateTabCount();
        return tab;
    }

    private boolean isCurrent(Tab t) {
        return !tabs.isEmpty() && curIdx < tabs.size() && tabs.get(curIdx) == t;
    }

    private void switchTo(int idx) {
        curIdx = idx;
        Tab t = cur();
        try {
            geckoView.releaseSession();
        } catch (Exception ignored) {
        }
        geckoView.setSession(t.session);
        hideBanner();
        updateNavButtons();
        urlBar.setText(displayUrl(t.url));
        progress.setVisibility(View.INVISIBLE);
        updateTabCount();
    }

    private void openNewTab(String url) {
        Tab t = createTab();
        t.url = url;
        switchTo(tabs.indexOf(t));
        t.session.loadUri(url);
    }

    private void closeTab(int idx) {
        Tab t = tabs.get(idx);
        boolean wasCurrent = (idx == curIdx);
        if (wasCurrent) {
            try {
                geckoView.releaseSession();
            } catch (Exception ignored) {
            }
        }
        tabs.remove(idx);
        t.session.close();

        if (tabs.isEmpty()) {
            Tab n = createTab();
            switchTo(tabs.indexOf(n));
            n.session.loadUri(START_URL);
            return;
        }
        if (idx < curIdx) curIdx--;
        if (wasCurrent) {
            switchTo(Math.min(idx, tabs.size() - 1));
        } else {
            updateTabCount();
        }
    }

    private void updateTabCount() {
        tabsBtn.setText(String.valueOf(tabs.size()));
    }

    private void updateNavButtons() {
        btnBack.setAlpha(cur().canBack ? 1f : 0.35f);
        btnForward.setAlpha(cur().canForward ? 1f : 0.35f);
    }

    private void openTabPanel() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        refreshTabPanel();
        geckoView.setVisibility(View.INVISIBLE);
        tabPanel.setVisibility(View.VISIBLE);
    }

    private void closeTabPanel() {
        tabPanel.setVisibility(View.GONE);
        geckoView.setVisibility(View.VISIBLE);
    }

    private void refreshTabPanel() {
        tabList.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(10), dp(6), dp(10));
            row.setBackgroundResource(i == curIdx ? R.drawable.bg_banner : R.drawable.bg_card);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(8);

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);

            TextView title = new TextView(this);
            title.setText(tabLabel(t));
            title.setTextColor(0xFFF3F4F6);
            title.setTextSize(15);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            texts.addView(title);

            TextView url = new TextView(this);
            url.setText(t.url.isEmpty() || t.url.startsWith("resource://") ? "Startseite" : t.url);
            url.setTextColor(0xFF9CA3AF);
            url.setTextSize(12);
            url.setSingleLine(true);
            url.setEllipsize(android.text.TextUtils.TruncateAt.END);
            texts.addView(url);

            row.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            Button x = new Button(this);
            x.setText("✕");
            x.setTextColor(0xFF9CA3AF);
            x.setBackgroundColor(0x00000000);
            x.setMinWidth(0);
            x.setOnClickListener(v -> {
                closeTab(idx);
                refreshTabPanel();
            });
            row.addView(x, new LinearLayout.LayoutParams(dp(48), dp(44)));

            row.setOnClickListener(v -> {
                closeTabPanel();
                switchTo(idx);
            });
            tabList.addView(row, rlp);
        }
    }

    private String tabLabel(Tab t) {
        if (!t.title.isEmpty()) return t.title;
        if (t.url.isEmpty() || t.url.startsWith("resource://")) return "Neuer Tab";
        String h = hostOf(t.url);
        return h != null ? h : t.url;
    }

    private String displayUrl(String url) {
        return (url == null || url.startsWith("resource://")) ? "" : url;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ================= Einstellungen =================
    private void applyDesktopMode(GeckoSession gs, boolean desktop) {
        gs.getSettings().setUserAgentMode(desktop
                ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                : GeckoSessionSettings.USER_AGENT_MODE_MOBILE);
        gs.getSettings().setViewportMode(desktop
                ? GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                : GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
    }

    private void applySettings() {
        if (tabs.isEmpty()) return;
        boolean ad = sp.getBoolean("adblock", true);
        boolean strict = sp.getInt("tracker", 1) == 1;
        int cookies = sp.getInt("cookies", 0);
        boolean desktop = sp.getBoolean("desktop", false);

        int base = strict ? ContentBlocking.AntiTracking.STRICT : ContentBlocking.AntiTracking.DEFAULT;
        int flags = ad
                ? (base | ContentBlocking.AntiTracking.AD | ContentBlocking.AntiTracking.ANALYTIC
                        | ContentBlocking.AntiTracking.SOCIAL | ContentBlocking.AntiTracking.CRYPTOMINING)
                : (base & ~ContentBlocking.AntiTracking.AD);
        ContentBlocking.Settings cb = sRuntime.getSettings().getContentBlocking();
        cb.setAntiTracking(flags);
        cb.setCookieBehavior(cookies == 0
                ? ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS
                : cookies == 1
                    ? ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY
                    : ContentBlocking.CookieBehavior.ACCEPT_ALL);

        btnAd.setColorFilter(ad ? 0xFF8B5CF6 : 0xFF6B7280);
        applyAdExtension(ad);
        for (Tab t : tabs) applyDesktopMode(t.session, desktop);

        boolean changed = (lastAd != null && lastAd != ad)
                || (lastDesktop != null && lastDesktop != desktop);
        lastAd = ad;
        lastDesktop = desktop;
        if (changed) cur().session.reload();
    }

    // ================= Werbeblocker-Erweiterung =================
    private void setupAdExtension() {
        if (sAdSetupStarted) return;
        sAdSetupStarted = true;
        sRuntime.getWebExtensionController()
                .ensureBuiltIn("resource://android/assets/ghostblock/", "ghostblock@ghostbrowser.app")
                .then(ext -> {
                    sAdExt = ext;
                    runOnUiThread(() -> applyAdExtension(sp.getBoolean("adblock", true)));
                    return null;
                });
    }

    private void applyAdExtension(boolean on) {
        if (sAdExt == null) return;
        WebExtensionController c = sRuntime.getWebExtensionController();
        if (on) {
            c.enable(sAdExt, WebExtensionController.EnableSource.USER);
        } else {
            c.disable(sAdExt, WebExtensionController.EnableSource.USER);
        }
    }

    // ================= Hilfsfunktionen =================
    private void showBanner(String uri, boolean newWindow) {
        runOnUiThread(() -> {
            pendingUri = uri;
            pendingNewTab = newWindow;
            bannerText.setText((newWindow ? "Neues Fenster blockiert:\n" : "Weiterleitung blockiert:\n") + uri);
            banner.setVisibility(View.VISIBLE);
        });
    }

    private void hideBanner() {
        runOnUiThread(() -> {
            pendingUri = null;
            pendingNewTab = false;
            banner.setVisibility(View.GONE);
        });
    }

    private static String hostOf(String uri) {
        try {
            Uri u = Uri.parse(uri);
            String scheme = u.getScheme();
            if (scheme == null) return null;
            if (!scheme.equals("http") && !scheme.equals("https")) return null;
            String h = u.getHost();
            return h == null ? null : h.toLowerCase();
        } catch (Exception e) {
            return null;
        }
    }

    private static String baseDomain(String host) {
        if (host == null || host.isEmpty()) return "";
        String[] p = host.split("\\.");
        if (p.length <= 2) return host;
        String last = p[p.length - 1];
        String second = p[p.length - 2];
        if (last.length() == 2 && second.length() <= 3 && p.length >= 3) {
            return p[p.length - 3] + "." + second + "." + last;
        }
        return second + "." + last;
    }

    private String writeConfig() {
        try {
            File f = new File(getFilesDir(), "geckoview-config.yaml");
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(buildConfig().getBytes("UTF-8"));
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    private String searchUrl() {
        int i = sp.getInt("search2", 0);
        if (i < 0 || i >= SEARCH_URLS.length) i = 0;
        return SEARCH_URLS[i];
    }

    private String toUrl(String input) {
        String t = input.trim();
        if (t.isEmpty()) return START_URL;
        if (t.contains(" ") || !t.contains(".")) {
            return searchUrl() + Uri.encode(t);
        }
        if (!t.contains("://")) return "https://" + t;
        return t;
    }

    @Override
    public void onBackPressed() {
        if (tabPanel.getVisibility() == View.VISIBLE) {
            closeTabPanel();
        } else if (cur().canBack) {
            cur().session.goBack();
        } else if (tabs.size() > 1) {
            closeTab(curIdx);
        } else {
            super.onBackPressed();
        }
    }
}
