package com.example.ghostbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.geckoview.StorageController;

public class SettingsActivity extends Activity {
    static final String PREFS = "ghost";

    private SharedPreferences sp;
    private LinearLayout root;
    private LinearLayout card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF0F0F14);
        sv.setFitsSystemWindows(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(32));
        sv.addView(root);
        setContentView(sv);

        // Kopfzeile
        TextView back = text("←  Einstellungen", 20, 0xFFF3F4F6);
        back.setPadding(dp(4), dp(12), dp(4), dp(16));
        back.setOnClickListener(v -> finish());
        root.addView(back);

        section("Schutz");
        switchRow("Werbeblocker", "Blockiert bekannte Werbe- und Tracking-Server (auch per Schild-Symbol unten)", "adblock", true);
        switchRow("Weiterleitungs-Schutz", "Fremde Weiterleitungen blockieren; oben erscheint ein Balken mit dem Link", "redirect_guard", true);
        switchRow("Anti-Fingerprinting", "Webseiten sehen einheitliche Gerätedaten (gilt nach komplettem Neustart der App)", "fingerprint", true);
        radioRow("Tracker-Schutz", new String[]{"Standard", "Streng (empfohlen)"}, "tracker", 1);

        section("Cookies & Anmeldung");
        radioRow("Cookies", new String[]{
                "Pro Webseite getrennt (empfohlen, Logins bleiben)",
                "Alle Drittanbieter-Cookies blockieren",
                "Alle Cookies erlauben"}, "cookies", 0);
        Button clear = new Button(this);
        clear.setText("Alle Cookies löschen");
        clear.setAllCaps(false);
        clear.setTextColor(0xFFFFFFFF);
        clear.setBackgroundResource(R.drawable.bg_btn);
        clear.setOnClickListener(v -> new AlertDialog.Builder(SettingsActivity.this)
                .setTitle("Alle Cookies löschen?")
                .setMessage("Du wirst danach auf allen Webseiten abgemeldet.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Löschen", (d, w) -> {
                    if (MainActivity.sRuntime != null) {
                        MainActivity.sRuntime.getStorageController()
                                .clearData(StorageController.ClearFlags.COOKIES);
                    }
                    Toast.makeText(SettingsActivity.this, "Cookies gelöscht", Toast.LENGTH_SHORT).show();
                })
                .show());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        lp.topMargin = dp(10);
        card.addView(clear, lp);

        section("Suche & Anzeige");
        radioRow("Suchmaschine", new String[]{"Google", "Brave Search", "Startpage", "DuckDuckGo", "Qwant"}, "search2", 0);
        switchRow("Desktop-Seiten", "Webseiten in der Desktop-Ansicht laden", "desktop", false);

        TextView info = text("Ghost Browser 1.0  ·  Firefox-Engine (GeckoView)", 12, 0xFF6B7280);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(18), 0, 0);
        root.addView(info);
    }

    // ---------- Bausteine ----------
    private void section(String title) {
        TextView t = text(title.toUpperCase(), 12, 0xFFC4B5FD);
        t.setPadding(dp(6), dp(14), 0, dp(6));
        root.addView(t);
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(8), dp(16), dp(12));
        root.addView(card, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void switchRow(String title, String subtitle, String key, boolean def) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(title, 16, 0xFFF3F4F6));
        TextView sub = text(subtitle, 12, 0xFF9CA3AF);
        sub.setPadding(0, dp(2), 0, 0);
        left.addView(sub);
        row.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((CompoundButton b, boolean on) ->
                sp.edit().putBoolean(key, on).apply());
        row.addView(sw);
        card.addView(row);
    }

    private void radioRow(String title, String[] options, String key, int def) {
        TextView t = text(title, 16, 0xFFF3F4F6);
        t.setPadding(0, dp(10), 0, dp(4));
        card.addView(t);

        RadioGroup group = new RadioGroup(this);
        int current = sp.getInt(key, def);
        for (int i = 0; i < options.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(View.generateViewId());
            rb.setText(options[i]);
            rb.setTextColor(0xFFD1D5DB);
            rb.setTextSize(14);
            rb.setButtonTintList(ColorStateList.valueOf(0xFF8B5CF6));
            rb.setPadding(dp(8), dp(8), 0, dp(8));
            group.addView(rb);
            if (i == current) rb.setChecked(true);
        }
        group.setOnCheckedChangeListener((g, id) -> {
            int idx = g.indexOfChild(g.findViewById(id));
            if (idx >= 0) sp.edit().putInt(key, idx).apply();
        });
        card.addView(group);
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
